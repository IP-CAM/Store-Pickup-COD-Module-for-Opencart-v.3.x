# 



## Getting Started

### Installing

Copy the files from the install directory to your store.

## Authors

* **Joe Rothrock** - *Initial work* - [akmjoe](https://github.com/akmjoe)

## License

This project is licensed under the GPL License - see the [LICENSE.md](LICENSE.md) file for details



